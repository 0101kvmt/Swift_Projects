//
//  ViewController.swift
//  there
//
//  Created by Kevin M Tran on 1/17/17.
//  Copyright © 2017 Kevin M Tran. All rights reserved.
//

import UIKit


// ADD FEATURE(SAVE/CANCEL) WORKED PERFECTLY BEFORE WORKING ON UPDATE/DELETE FEATURE. WILL COME BACK TO THIS WHEN I GET THE CHANCE.

class BucketListViewController: UITableViewController, AddItemTableViewControllerDelegate {
    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        print("cancel")
    }

    var item = ["one", "two", "three"]
    override func viewDidLoad() {
        super.viewDidLoad()
        print("loaded")
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListItemCell", for: indexPath)
        cell.textLabel?.text = item[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("selected")
    }
    
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
         performSegue(withIdentifier: "EditItemSegue", sender: indexPath)
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        item.remove(at: indexPath.row)
        tableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddItemSegue"{

        let navigationController = segue.destination as! UINavigationController
        let addItemTableViewController = navigationController.topViewController as! AddItemTableViewController
        addItemTableViewController.delegate = self
        } else if segue.identifier == "EditItemSegue"{
            let navigationController = segue.destination as! UINavigationController
            let addItemTableViewController = navigationController.topViewController as! AddItemTableViewController
            addItemTableViewController.delegate = self
            
            let indexPath = sender as! NSIndexPath
            let itemz = item[indexPath.row]
            
            addItemTableViewController.item = itemz
            addItemTableViewController.indexPath = indexPath

        }
    }
    func cancelButtonPressed(by controller: AddItemTableViewController) {
        print("hidden controller, but i am responding to the cancel button press on the top view controller")
        dismiss(animated: true, completion: nil)
    }
    func itemSaved(by controller: AddItemTableViewController, with text: String, at indexPath: NSIndexPath?){
        
        if let ip = indexPath {
            item[ip.row] = text
        } else{
            item.append(text)
        }
        print("hidden controller, but i am responding to the save button press on the top view controller")
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
}

